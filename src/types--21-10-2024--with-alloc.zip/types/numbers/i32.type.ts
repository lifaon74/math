export type i32 = number;
