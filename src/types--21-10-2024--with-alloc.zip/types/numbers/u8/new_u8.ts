import { AllocFunction } from '../../alloc/alloc-function.type.js';
import { BytesBuffer } from '../../bytes-buffer/bytes-buffer.type.js';
import { usize } from '../usize/usize.type.js';
import { alloc_u8 } from './alloc_u8.js';
import { u8 } from './u8.type.js';
import { write_u8 } from './write_u8.js';

export function new_u8(buffer: BytesBuffer, alloc: AllocFunction, value: u8): usize {
  const index: usize = alloc_u8(alloc);
  write_u8(buffer, index, value);
  return index;
}
