import { AllocFunction } from '../../alloc/alloc-function.type.js';
import { BytesBuffer } from '../../bytes-buffer/bytes-buffer.type.js';
import { usize } from '../usize/usize.type.js';
import { alloc_u16 } from './alloc_u16.js';
import { u16 } from './u16.type.js';
import { write_u16_le } from './write_u16_le.js';

export function new_u16_le(buffer: BytesBuffer, alloc: AllocFunction, value: u16): usize {
  const index: usize = alloc_u16(alloc);
  write_u16_le(buffer, index, value);
  return index;
}
