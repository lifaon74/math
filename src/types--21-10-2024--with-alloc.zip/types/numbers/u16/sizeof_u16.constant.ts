export const SIZEOF_U16 = 2;
