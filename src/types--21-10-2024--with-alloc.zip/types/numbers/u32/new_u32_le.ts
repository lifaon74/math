import { AllocFunction } from '../../alloc/alloc-function.type.js';
import { BytesBuffer } from '../../bytes-buffer/bytes-buffer.type.js';
import { usize } from '../usize/usize.type.js';
import { alloc_u32 } from './alloc_u32.js';
import { u32 } from './u32.type.js';
import { write_u32_le } from './write_u32_le.js';

export function new_u32_le(buffer: BytesBuffer, alloc: AllocFunction, value: u32): usize {
  const index: usize = alloc_u32(alloc);
  write_u32_le(buffer, index, value);
  return index;
}
