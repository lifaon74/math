export type i8 = number;
