import { is_point_in_segment_1d } from '../../../1d/inside/is-point-in-segment-1d';
import { are_line_segments_intersecting_1d } from '../../../1d/intersection/are-line-segments-intersecting-1d';

export function areLineSegmentsIntersecting2D(
  // segment AB
  // point A
  a_x: number,
  a_y: number,
  // point B
  b_x: number,
  b_y: number,
  // segment CD
  // point C
  c_x: number,
  c_y: number,
  // point D
  d_x: number,
  d_y: number,
): boolean {
  const d_ab_x: number = b_x - a_x; // distance AB on x axis
  const d_cd_x: number = d_x - c_x; // distance CD on x axis
  if (d_ab_x === 0) { // AB is vertical
    if (d_cd_x === 0) {  // CD is vertical => both parallel
      return are_line_segments_intersecting_1d(
        a_y,
        b_y,
        c_y,
        d_y,
      );
    } else {
      return is_point_in_segment_1d(
        (((d_y - c_y) * (a_x - c_x)) / d_cd_x) + c_y,
        a_y,
        b_y,
      );
    }
  } else if (d_cd_x === 0) { // CD is vertical and AB is not parallel to CD
    return is_point_in_segment_1d(
      (((b_y - a_y) * (c_x - a_x)) / d_ab_x) + a_y,
      c_y,
      d_y,
    );
  } else { // none of AB or CD is vertical
    const ab_a: number = (b_y - a_y) / d_ab_x; // compute 'a' of AB line
    const cd_a: number = (d_y - c_y) / d_cd_x; // compute 'a' of CD line
    if (ab_a === cd_a) { // AB and CD are parallel
      return are_line_segments_intersecting_1d(
        a_x,
        b_x,
        c_x,
        d_x,
      );
    } else {
      const ab_b: number = a_y - (ab_a * a_x); // compute 'b' of AB line
      const cd_b: number = c_y - (cd_a * c_x); // compute 'b' of CD line
      const p_x: number = (cd_b - ab_b) / (ab_a - cd_a);
      // const p_y: number = ab_a * p_x + ab_b;
      return is_point_in_segment_1d(
        p_x,
        a_x,
        b_x,
      );
      // return isPointInRectangle2D(
      //   p_x,
      //   p_y,
      //   a_x,
      //   a_y,
      //   b_x,
      //   b_y,
      // );
    }
  }
}
