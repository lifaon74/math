import { normalized_arc_tan2 } from '../../../angles/normalized-atan2';
import { is_angle_in_arc } from '../../../angles/is-angle-in-arc';
import { is_point_2d_in_rectangle_2d } from '../../inside/is-point-2d-in-rectangle-2d';
import { is_point_in_segment_1d } from '../../../1d/inside/is-point-in-segment-1d';

export function isLineSegmentIntersectingWithArc2D(
  // segment AB
  // point A
  a_x: number,
  a_y: number,
  // point B
  b_x: number,
  b_y: number,
  // arc
  // center
  arc_center_x: number,
  arc_center_y: number,
  // radius
  arc_radius: number,
  // angles
  arc_start_angle: number, // [0, PHI[
  arc_end_angle: number, // [0, PHI[
): boolean {

  const d_ab_x: number = b_x - a_x;

  if (d_ab_x === 0) { // AB is vertical
    const d_ca_x: number = a_x - arc_center_x;

    if (Math.abs(d_ca_x) <= arc_radius) { // line AB is intersecting with the circle
      const dy: number = Math.sqrt(Math.pow(arc_radius, 2) - Math.pow(d_ca_x, 2));

      if (dy === 0) {
        return (
          is_point_in_segment_1d(
            arc_center_y,
            a_y,
            b_y,
          ) && is_angle_in_arc(
            (d_ca_x >= 0) ? 0 : Math.PI,
            arc_start_angle,
            arc_end_angle,
          )
        );
      } else {
        return (
          is_point_in_segment_1d(
            arc_center_y - dy,
            a_y,
            b_y,
          ) && is_angle_in_arc(
            normalized_arc_tan2(-dy, d_ca_x),
            arc_start_angle,
            arc_end_angle,
          )
        ) || (
          is_point_in_segment_1d(
            arc_center_y + dy,
            a_y,
            b_y,
          ) && is_angle_in_arc(
            normalized_arc_tan2(dy, d_ca_x),
            arc_start_angle,
            arc_end_angle,
          )
        );
      }
    } else {
      return false;
    }
  } else {
    const ab_a: number = (b_y - a_y) / d_ab_x;
    const ab_b: number = a_y - (ab_a * a_x);

    const a: number = Math.pow(ab_a, 2) + 1;
    const b: number = 2 * ((ab_a * (ab_b - arc_center_y)) - arc_center_x);
    const c: number = Math.pow(arc_center_x, 2) + Math.pow(ab_b - arc_center_y, 2) - Math.pow(arc_radius, 2);

    const d: number = Math.pow(b, 2) - (4 * a * c);

    if (d >= 0) { // AB is intersecting with the circle
      const sqrt_d: number = Math.sqrt(d);
      const p_x_0: number = (-b - sqrt_d) / (2 * a);
      const p_y_0: number = p_x_0 * ab_a + ab_b;

      if (
        is_point_2d_in_rectangle_2d(
          p_x_0,
          p_y_0,
          a_x,
          a_y,
          b_x,
          b_y,
        ) && is_angle_in_arc(
          normalized_arc_tan2(p_y_0 - arc_center_y, p_x_0 - arc_center_x),
          arc_start_angle,
          arc_end_angle,
        )
      ) {
        return true;
      } else if (sqrt_d !== 0) {
        const p_x_1: number = (-b + sqrt_d) / (2 * a);
        const p_y_1: number = p_x_1 * ab_a + ab_b;

        return is_point_2d_in_rectangle_2d(
          p_x_1,
          p_y_1,
          a_x,
          a_y,
          b_x,
          b_y,
        ) && is_angle_in_arc(
          normalized_arc_tan2(p_y_1 - arc_center_y, p_x_1 - arc_center_x),
          arc_start_angle,
          arc_end_angle,
        );
      } else {
        return false;
      }
    } else {
      return false;
    }
  }
}

