export type BytesBuffer = Uint8Array;
