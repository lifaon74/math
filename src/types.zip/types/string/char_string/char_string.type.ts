export type char_string = string;
