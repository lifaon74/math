export const SIZEOF_U32 = 4;
